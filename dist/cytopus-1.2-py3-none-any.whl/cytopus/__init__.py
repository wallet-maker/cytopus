"""A Knowledge Base for Single Cell Biology"""

from . import KnowledgeBase as kb
